/*
### Step 2: Redefine the `Rainfall` Class to Use Vectors

need a place to hold each rainfall record - let's use struct
*/

class Rainfall {
// vector of RainfallRecord

public:
// method to add rainfall data

// method to calculate average rainfall for a city
};
